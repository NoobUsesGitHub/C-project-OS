Turn around time Calculator
how to run?
java -jar TurnAroundCalculator.jar <your file path (full) here>


how to build jar(in case needed):
& "C:\Program Files\Java\jdk-25.0.2\bin\jar.exe" cfe .\TurnAroundCalculator.jar MainPackage.ProcessPackage.TurnAroundCalculator -C .\build-jar .